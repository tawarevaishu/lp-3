#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int n, capacity;

    cout << "Enter number of items: ";
    cin >> n;
    cout << "Enter knapsack capacity: ";
    cin >> capacity;

    if (n <= 0 || capacity < 0) {
        cout << "Invalid input.\n";
        return 0;
    }

    vector<int> weight(n + 1), value(n + 1);

    cout << "Enter weight and value of each item:\n";
    for (int i = 1; i <= n; i++)
        cin >> weight[i] >> value[i];

    vector<vector<int>> dp(n + 1, vector<int>(capacity + 1, 0));

    // Build the DP table.
    for (int i = 1; i <= n; i++) {
        for (int w = 0; w <= capacity; w++) {
            dp[i][w] = dp[i - 1][w];

            if (weight[i] <= w) {
                dp[i][w] = max(dp[i][w],
                               value[i] + dp[i - 1][w - weight[i]]);
            }
        }
    }

    cout << "\nDP Table:\n";
    cout << "Items/Cap ";
    for (int w = 0; w <= capacity; w++)
        cout << w << "\t";
    cout << '\n';

    for (int i = 0; i <= n; i++) {
        cout << i << "\t   ";
        for (int w = 0; w <= capacity; w++)
            cout << dp[i][w] << "\t";
        cout << '\n';
    }

    cout << "\nMaximum value = " << dp[n][capacity] << '\n';

    // Trace the table to find which items were selected.
    vector<int> selected;
    int w = capacity;
    for (int i = n; i > 0; i--) {
        if (dp[i][w] != dp[i - 1][w]) {
            selected.push_back(i);
            w -= weight[i];
        }
    }

    reverse(selected.begin(), selected.end());
    cout << "Selected item numbers: ";
    if (selected.empty())
        cout << "None";
    else
        for (int item : selected)
            cout << item << " ";
    cout << '\n';

    return 0;
}

/*
Sample Input:
4
7
1 1
3 4
4 5
5 7

Sample Output:
Enter number of items: 4
Enter knapsack capacity: 7
Enter weight and value of each item:
1 1
3 4
4 5
5 7

DP Table:
Items/Cap 0  1  2  3  4  5  6  7
0         0  0  0  0  0  0  0  0
1         0  1  1  1  1  1  1  1
2         0  1  1  4  5  5  5  5
3         0  1  1  4  5  6  6  9
4         0  1  1  4  5  7  8  9

Maximum value = 9
Selected item numbers: 2 3

Time Complexity: O(n * W), where n is the number of items
and W is the knapsack capacity.
Space Complexity: O(n * W) for the DP table.
*/
