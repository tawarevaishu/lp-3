#include <iostream>
using namespace std;

// Fibonacci using both iterative (non-recursive) and recursive methods.
long long fibonacciRecursive(int n) {
    if (n <= 1)
        return n;
    return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
}

long long fibonacciIterative(int n) {
    if (n <= 1)
        return n;

    long long a = 0, b = 1;
    for (int i = 2; i <= n; i++) {
        long long next = a + b;
        a = b;
        b = next;
    }
    return b;
}

int main() {
    int n;
    cout << "Enter the number of terms: ";
    cin >> n;

    if (n < 0 || n > 90) {
        cout << "Please enter a value between 0 and 90.\n";
        return 0;
    }

    cout << "\nFibonacci series (non-recursive): ";
    for (int i = 0; i < n; i++)
        cout << fibonacciIterative(i) << " ";

    cout << "\nFibonacci series (recursive): ";
    for (int i = 0; i < n; i++)
        cout << fibonacciRecursive(i) << " ";

    cout << "\n";
    return 0;
}

/*
Sample Output:
Enter the number of terms: 7

Fibonacci series (non-recursive): 0 1 1 2 3 5 8
Fibonacci series (recursive): 0 1 1 2 3 5 8

Time Complexity:
- Iterative: O(n) for calculating one Fibonacci number.
- Recursive (basic): O(2^n) due to repeated calculations.

Space Complexity:
- Iterative: O(1).
- Recursive: O(n) due to the function call stack.
*/
