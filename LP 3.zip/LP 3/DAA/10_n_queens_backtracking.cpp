#include <iostream>
#include <vector>
using namespace std;

bool isSafe(const vector<vector<int>>& board, int row, int col, int n) {
    // Check the same column in previous rows.
    for (int i = 0; i < row; i++)
        if (board[i][col] == 1)
            return false;

    // Check upper-left diagonal.
    for (int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--)
        if (board[i][j] == 1)
            return false;

    // Check upper-right diagonal.
    for (int i = row - 1, j = col + 1; i >= 0 && j < n; i--, j++)
        if (board[i][j] == 1)
            return false;

    return true;
}

bool solveNQueens(vector<vector<int>>& board, int row, int n) {
    if (row == n)
        return true;

    // Try placing a queen in each column of the current row.
    for (int col = 0; col < n; col++) {
        if (isSafe(board, row, col, n)) {
            board[row][col] = 1;

            if (solveNQueens(board, row + 1, n))
                return true;

            // Backtrack if this position does not lead to a solution.
            board[row][col] = 0;
        }
    }

    return false;
}

int main() {
    int n;
    cout << "Enter value of N: ";
    cin >> n;

    if (n <= 0 || n > 15) {
        cout << "Enter N between 1 and 15.\n";
        return 0;
    }

    vector<vector<int>> board(n, vector<int>(n, 0));

    // Fix the first queen at row 0, column 0.
    board[0][0] = 1;

    if (solveNQueens(board, 1, n)) {
        cout << "\nN-Queens solution (1 = Queen, 0 = Empty):\n";
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++)
                cout << board[i][j] << " ";
            cout << '\n';
        }
    } else {
        cout << "No solution exists with the first queen at (0, 0).\n";
    }

    return 0;
}

/*
Sample Output:
Enter value of N: 4

N-Queens solution (1 = Queen, 0 = Empty):
1 0 0 0
0 0 1 0
0 0 0 0 1
0 1 0 0

Time Complexity: O(N!) in the worst case, since the algorithm
tries possible column placements row by row and backtracks.
Space Complexity: O(N^2) for the board and O(N) recursion stack.

Note: The first queen is fixed at position (0, 0).
*/
