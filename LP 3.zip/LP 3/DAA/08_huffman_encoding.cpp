#include <iostream>
#include <queue>
#include <vector>
#include <string>
using namespace std;

struct Node {
    char ch;
    int frequency;
    Node *left, *right;

    Node(char c, int f) : ch(c), frequency(f), left(nullptr), right(nullptr) {}
};

struct Compare {
    bool operator()(Node* a, Node* b) {
        return a->frequency > b->frequency;
    }
};

void generateCodes(Node* root, const string& code) {
    if (!root)
        return;

    if (!root->left && !root->right) {
        cout << root->ch << " : " << (code.empty() ? "0" : code) << '\n';
        return;
    }

    generateCodes(root->left, code + "0");
    generateCodes(root->right, code + "1");
}

void deleteTree(Node* root) {
    if (!root)
        return;
    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

int main() {
    int n;
    cout << "Enter number of characters: ";
    cin >> n;

    if (n <= 0) {
        cout << "Number of characters must be positive.\n";
        return 0;
    }

    priority_queue<Node*, vector<Node*>, Compare> minHeap;

    cout << "Enter character and frequency:\n";
    for (int i = 0; i < n; i++) {
        char ch;
        int frequency;
        cin >> ch >> frequency;

        if (frequency < 0) {
            cout << "Frequency cannot be negative.\n";
            while (!minHeap.empty()) {
                deleteTree(minHeap.top());
                minHeap.pop();
            }
            return 0;
        }
        minHeap.push(new Node(ch, frequency));
    }

    while (minHeap.size() > 1) {
        Node* left = minHeap.top();
        minHeap.pop();

        Node* right = minHeap.top();
        minHeap.pop();

        Node* parent = new Node('\0',
                                left->frequency + right->frequency);
        parent->left = left;
        parent->right = right;
        minHeap.push(parent);
    }

    Node* root = minHeap.top();

    cout << "\nHuffman Codes:\n";
    generateCodes(root, "");

    deleteTree(root);
    return 0;
}

/*
Sample Input:
6
a 5
b 9
c 12
d 13
e 16
f 45

Sample Output (one valid set of codes; ties can change code assignments):
Enter number of characters: 6
Enter character and frequency:
a 5
b 9
c 12
d 13
e 16
f 45

Huffman Codes:
f : 0
c : 100
d : 101
a : 1100
b : 1101
e : 111

Time Complexity:
- Building the priority queue: O(n).
- Combining nodes: O(n log n).
- Generating codes: O(n).
Overall Time Complexity: O(n log n).
Space Complexity: O(n) for the tree and priority queue.
*/
