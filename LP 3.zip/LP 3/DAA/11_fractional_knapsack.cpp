#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;

struct Item {
    int weight;
    int value;
    double ratio;
};

bool compareRatio(const Item& a, const Item& b) {
    return a.ratio > b.ratio;
}

int main() {
    int n, capacity;

    cout << "Enter number of items: ";
    cin >> n;
    cout << "Enter knapsack capacity: ";
    cin >> capacity;

    if (n <= 0 || capacity < 0) {
        cout << "Invalid input.\n";
        return 0;
    }

    vector<Item> items(n);

    cout << "Enter weight and value of each item:\n";
    for (int i = 0; i < n; i++) {
        cin >> items[i].weight >> items[i].value;

        if (items[i].weight <= 0 || items[i].value < 0) {
            cout << "Weight must be positive and value cannot be negative.\n";
            return 0;
        }

        items[i].ratio = static_cast<double>(items[i].value) /
                         items[i].weight;
    }

    // Sort items by decreasing value-to-weight ratio.
    sort(items.begin(), items.end(), compareRatio);

    double totalValue = 0.0;
    int remainingCapacity = capacity;

    cout << fixed << setprecision(2);

    for (const Item& item : items) {
        if (remainingCapacity == 0)
            break;

        if (item.weight <= remainingCapacity) {
            totalValue += item.value;
            remainingCapacity -= item.weight;
        } else {
            double fraction = static_cast<double>(remainingCapacity) /
                              item.weight;
            totalValue += item.value * fraction;
            remainingCapacity = 0;
        }
    }

    cout << "\nMaximum value in knapsack = " << totalValue << '\n';
    return 0;
}

/*
Sample Input:
3
50
10 60
20 100
30 120

Sample Output:
Enter number of items: 3
Enter knapsack capacity: 50
Enter weight and value of each item:
10 60
20 100
30 120

Maximum value in knapsack = 240.00

Time Complexity:
- Calculating ratios: O(n).
- Sorting items: O(n log n).
- Selecting items: O(n).
Overall Time Complexity: O(n log n).
Space Complexity: O(n) for storing the items.
*/
