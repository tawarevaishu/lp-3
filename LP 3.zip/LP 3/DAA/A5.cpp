
#include <iostream>
#include <vector>
using namespace std;

bool isSafe(const vector<vector<int>>& board, int row, int col, int n) {
    // Check the same column in previous rows.
    for (int i = 0; i < row; i++)
        if (board[i][col] == 1)
            return false;

    // Check upper-left diagonal.
    for (int i = row - 1, j = col - 1; i >= 0 && j >= 0; i--, j--)
        if (board[i][j] == 1)
            return false;

    // Check upper-right diagonal.
    for (int i = row - 1, j = col + 1; i >= 0 && j < n; i--, j++)
        if (board[i][j] == 1)
            return false;

    return true;
}

bool solveNQueens(vector<vector<int>>& board, int row, int n) {
    if (row == n)
        return true;

    // Try placing a queen in each column.
    for (int col = 0; col < n; col++) {
        if (isSafe(board, row, col, n)) {
            board[row][col] = 1;

            if (solveNQueens(board, row + 1, n))
                return true;

            // Backtrack.
            board[row][col] = 0;
        }
    }

    return false;
}

int main() {
    int n;

    cout << "Enter value of N: ";
    cin >> n;

    if (n <= 0 || n > 15) {
        cout << "Enter N between 1 and 15.\n";
        return 0;
    }

    vector<vector<int>> board(n, vector<int>(n, 0));

    // Fix the first queen at row 0, column 0.
    board[0][0] = 1;

    if (solveNQueens(board, 1, n)) {
        cout << "\nN-Queens Solution (Q = Queen, . = Empty):\n";

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (board[i][j] == 1)
                    cout << "Q ";
                else
                    cout << ". ";
            }
            cout << '\n';
        }
    } else {
        cout << "No solution exists with the first queen at (0, 0).\n";
    }

    return 0;
}

